# OrbitalStrike (Paper 1.21.11)

Original Paper plugin. Items: Stab Shot, Nuke Shot, Orbital Wolf, Stasis, Orbital Railgun.
Also: crafting, death-ban, proximity join/leave/death messages.

## Build (GitHub, no installs)
1. Create a free account at github.com, then New repository (any name).
2. Upload ALL files from this folder (including the hidden .github folder) -> Commit.
3. Open the "Actions" tab -> "Build plugin" -> wait ~1-2 min until green.
4. Open the finished run -> Artifacts -> download "OrbitalStrike-jar" -> unzip -> OrbitalStrike-1.0.0.jar.
5. Put the jar into your server's `plugins/` folder and restart.

## Build locally
Install JDK 21 and Gradle 8.x, then run `gradle build` in this folder. Jar: build/libs/.

## Commands (/os, /ostrike, /orbitalstrike)
- /os give stab|nuke|wolf|stasis|railgun [amount] [param]   (admin)
- /os strike stab|nuke|wolf ...                              (admin)
- /os craft nuke|stab, /os recipes
- /os set <key> <value>, /os reload, /os resetdeaths <player> (admin)

Permissions: orbitalstrike.use (default true), orbitalstrike.craft (true), orbitalstrike.admin (op).
